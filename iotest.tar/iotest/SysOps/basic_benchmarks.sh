#!/bin/bash

#Random Write/Read
fio --randrepeat=1 --ioengine=libaio --direct=1 --gtod_reduce=1 --name=test --filename=test --bs=4k --iodepth=64 --size=4G --readwrite=randwrite
fio --randrepeat=1 --ioengine=libaio --direct=1 --gtod_reduce=1 --name=test --filename=test --bs=4k --iodepth=64 --size=4G --readwrite=randread

#Sequential Read/Write
## Number of jobs 1
fio --ioengine=libaio --direct=1 --name=sequential-write --filename=test --bs=1M --size=10G --runtime=600 --rw=write --numjobs=1 --group_reporting
fio --ioengine=libaio --direct=1 --name=sequential-read --filename=test --bs=1M --size=10G --runtime=600 --rw=read --numjobs=1 --group_reporting
## Number of jobs 8
fio --ioengine=libaio --direct=1 --name=sequential-write --filename=test --bs=1M --size=10G --runtime=600 --rw=write --numjobs=8 --group_reporting
fio --ioengine=libaio --direct=1 --name=sequential-read --filename=test --bs=1M --size=10G --runtime=600 --rw=read --numjobs=8 --group_reporting
## Number of jobs 32
fio --ioengine=libaio --direct=1 --name=sequential-write --filename=test --bs=1M --size=10G --runtime=600 --rw=write --numjobs=32 --group_reporting
fio --ioengine=libaio --direct=1 --name=sequential-read --filename=test --bs=1M --size=10G --runtime=600 --rw=read --numjobs=32 --group_reporting
