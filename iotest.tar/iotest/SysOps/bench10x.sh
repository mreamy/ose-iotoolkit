#!/bin/bash

TARGETS="ceph gluster nfs"
for l in `seq 1 10`
do
        for i in $TARGETS
        do
                echo "*********************************************************************************************"
                echo "*********************************************************************************************"
                echo "*********************************************************************************************"
                echo "*********************************************************************************************"
                echo Random Write/Read
                fio -name test --output="/tmp/miker/loop${l}_${i}_rand-write" --randrepeat=1 --ioengine=libaio --direct=1 --gtod_reduce=1 --directory=/${i}1 --bs=4k --iodepth=64 --size=4G --readwrite=randwrite
                echo "*********************************************************************************************"
                fio -name test --output="/tmp/miker/loop${l}_${i}_rand-read" --randrepeat=1 --ioengine=libaio --direct=1 --gtod_reduce=1 --directory=/${i}1 --bs=4k --iodepth=64 --size=4G --readwrite=randread
                echo "*********************************************************************************************"

                echo Sequential Read/Write
                echo  Number of jobs 1
                fio -name test --output="/tmp/miker/loop${l}_${i}_write" --ioengine=libaio --direct=1 --directory=/${i}1 --bs=1M --size=10G --runtime=600 --rw=write --numjobs=1 --group_reporting
                echo "*********************************************************************************************"
                fio -name test --output="/tmp/miker/loop${l}_${i}_read" --ioengine=libaio --direct=1 --directory=/${i}1 --bs=1M --size=10G --runtime=600 --rw=read --numjobs=1 --group_reporting
                echo "*********************************************************************************************"
                echo  Number of jobs 8
                fio -name test --output="/tmp/miker/${i}_write" --ioengine=libaio --direct=1 --directory=/${i}1 --bs=1M --size=10G --runtime=600 --rw=write --numjobs=8 --group_reporting
                echo "*********************************************************************************************"
                fio -name test --output="/tmp/miker/${i}_read" --ioengine=libaio --direct=1 --directory=/${i}1 --bs=1M --size=10G --runtime=600 --rw=read --numjobs=8 --group_reporting
                echo "*********************************************************************************************"
                echo  Number of jobs 32
                fio -name test --output="/tmp/miker/${i}_write" --ioengine=libaio --direct=1 --directory=/${i}1 --bs=1M --size=10G --runtime=600 --rw=write --numjobs=32 --group_reporting
                echo "*********************************************************************************************"
                fio -name test --output="/tmp/miker/${i}_read" --ioengine=libaio --direct=1 --directory=/${i}1 --bs=1M --size=10G --runtime=600 --rw=read --numjobs=32 --group_reporting
                echo "*********************************************************************************************"
                rm /${i}1/test
        done
done
cp /tmp/miker/* /nfs1/job_output

